import logging

from clusterman_signals.base_signal import BaseSignal
from clusterman_signals.base_signal import SignalResources

logger = logging.getLogger(__name__)


class AverageMostRecentCPU(BaseSignal):

    def value(self, metrics, timestamp):
        if len(metrics['cpus_allocated']) == 0:
            logger.error('No data in metrics_cache, emit None as SignalResources')
            return SignalResources()
        val = [sum(y) / len(y) for y in zip(*metrics['cpus_allocated'])]
        return SignalResources(cpus=val[1])
