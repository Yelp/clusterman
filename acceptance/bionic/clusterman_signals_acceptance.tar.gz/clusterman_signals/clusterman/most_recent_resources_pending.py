from clusterman_signals.base_signal import BaseSignal
from clusterman_signals.base_signal import SignalResources


class MostRecentResourcesPending(BaseSignal):
    def value(self, metrics, timestamp):
        resources = ['cpus', 'mem', 'disk', 'gpus']
        signal_resources = {}
        for resource in resources:
            allocated = metrics.get(resource + '_allocated', [])
            pending = metrics.get(resource + '_pending', [])
            latest_allocated = max(allocated, default=(None, None))
            latest_pending = max(pending, default=(None, None))

            if latest_allocated[1] is not None and latest_pending[1] is not None:
                signal_resources[resource] = latest_allocated[1] + latest_pending[1]
            else:
                signal_resources[resource] = latest_allocated[1]

        return SignalResources(
            cpus=signal_resources['cpus'],
            mem=signal_resources['mem'],
            disk=signal_resources['disk'],
            gpus=signal_resources['gpus'],
        )
