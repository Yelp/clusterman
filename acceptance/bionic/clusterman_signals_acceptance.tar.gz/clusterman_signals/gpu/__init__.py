from .gpu_signal import GPUSignal
from .marathon_gpu_signal import MarathonGPUSignal

__all__ = [
    'GPUSignal',
    'MarathonGPUSignal',
]
