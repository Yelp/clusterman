import marathon

from clusterman_signals.base_signal import BaseSignal
from clusterman_signals.base_signal import SignalResources

_MAX_CLIENTS = 20


class MarathonGPUSignal(BaseSignal):

    def __init__(self, logger, parameters):
        super().__init__(logger, parameters)
        self.clients = self._get_marathon_clients()

    def _get_marathon_clients(self):
        clients = []
        for i in range(_MAX_CLIENTS):  # dont infinite loop
            client = marathon.MarathonClient(
                f'http://marathon{i if i > 0 else ""}.paasta-{self.cluster}.yelp',
            )
            try:
                client.ping()
            # dns records exist for marathon servers <=20. if marathon isn't
            # running, we get a 502 (InternalServerError). >20, there are no
            # records, so we get a 404 (NotFoundError). we catch both for safety.
            except (marathon.exceptions.InternalServerError, marathon.exceptions.NotFoundError):
                break
            clients.append(client)
        return clients

    def value(self, metrics, timestamp):
        gpus = 0
        pool_constraint = ['pool', 'LIKE', self.pool]

        for marathon_client in self.clients:
            apps = marathon_client.list_apps()
            # Ignore non-gpu tasks
            for app in apps:
                if app.gpus <= 0:
                    continue
                for constraint in app.constraints:
                    if constraint.json_repr() == pool_constraint:
                        gpus += app.gpus * app.instances
                        break

        self.logger.info(f'Marathon requesting {gpus} gpus')

        return SignalResources(gpus=gpus)
