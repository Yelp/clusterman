from .jenkins_signal import JenkinsSignal

__all__ = [
    'JenkinsSignal',
]
