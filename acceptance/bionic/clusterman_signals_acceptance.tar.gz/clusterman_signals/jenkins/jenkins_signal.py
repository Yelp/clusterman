import enum
from operator import itemgetter

from clusterman_metrics.util.constants import APP_METRICS
from clusterman_metrics.util.meteorite import get_meteorite_identifiers

from clusterman_signals.base_signal import BaseSignal
from clusterman_signals.base_signal import SignalResources


class ScalingDecision(enum.Enum):
    UP = enum.auto()
    HOLD = enum.auto()
    DOWN = enum.auto()


def extract_cpus_available_per_host(metrics):
    host_to_cpus_avail = {}
    for name, time_series in metrics.items():
        if not name.startswith('cpus_available'):
            continue

        _, dims = get_meteorite_identifiers(APP_METRICS, name)
        _, latest_metric = max(time_series, key=itemgetter(0), default=(None, 0))
        host_to_cpus_avail[dims['host']] = latest_metric

    return host_to_cpus_avail


def decide_scaling(host_to_cpus_avail, constraints):
    decisions = []

    for constraint in constraints:
        slots_available_per_host = [
            cpus_available // constraint['cpus_per_slot']
            for cpus_available in host_to_cpus_avail.values()
        ]
        slots_available = sum(slots_available_per_host)
        hosts_with_slots = sum(1 for host_slots_avail in slots_available_per_host if host_slots_avail > 0)

        # If all the slots available are on one host we still shouldn't scale down
        if slots_available > constraint['slots_required'] and hosts_with_slots > 1:
            decisions.append(ScalingDecision.DOWN)
        elif slots_available < constraint['slots_required']:
            decisions.append(ScalingDecision.UP)
        else:  # slots_available == constraint['slots_required']
            decisions.append(ScalingDecision.HOLD)

    if any(decision == ScalingDecision.UP for decision in decisions):
        return ScalingDecision.UP
    elif any(decision == ScalingDecision.HOLD for decision in decisions):
        return ScalingDecision.HOLD
    else:  # all(decisions == DOWN)
        return ScalingDecision.DOWN


class JenkinsSignal(BaseSignal):

    def __init__(self, logger, parameters):
        super().__init__(logger, parameters)

    def value(self, metrics, timestamp):
        host_to_cpus_avail = extract_cpus_available_per_host(metrics)
        decision = decide_scaling(host_to_cpus_avail, self.parameters['constraints'])

        _, cpus_used = max(metrics['cpus_allocated'], key=itemgetter(0))
        cpus_available = sum(host_to_cpus_avail.values())

        if decision == ScalingDecision.DOWN:
            # This is what would be returned by the default autoscaler signal
            # with extra cpus for the slots we want to be available
            # so that it doesn't scale down too much
            max_cpus_for_constrains = max(
                constraint['slots_required'] * constraint['cpus_per_slot']
                for constraint in self.parameters['constraints']
            )
            cpus_to_request = cpus_used + max_cpus_for_constrains
        elif decision == ScalingDecision.HOLD:
            # Request our current size
            cpus_to_request = cpus_used + cpus_available
        elif decision == ScalingDecision.UP:
            # Request current size + a new host
            cpus_to_request = cpus_used + cpus_available + self.parameters['host_size']
        else:
            assert False, "We missed a ScalingDecision or decision got set to something else"

        # Use the same values as the default MostRecentResources signal for other resources
        _, most_recent_mem = max(metrics['mem_allocated'], default=(None, None))
        _, most_recent_disk = max(metrics['disk_allocated'], default=(None, None))
        _, most_recent_gpus = max(metrics['gpus_allocated'], default=(None, None))

        return SignalResources(
            cpus=cpus_to_request,
            mem=most_recent_mem,
            disk=most_recent_disk,
            gpus=most_recent_gpus,
        )
