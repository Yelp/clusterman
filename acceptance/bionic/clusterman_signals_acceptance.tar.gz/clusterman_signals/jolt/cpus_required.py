from operator import itemgetter

from clusterman_metrics.util.constants import APP_METRICS
from clusterman_metrics.util.meteorite import get_meteorite_identifiers

from clusterman_signals.base_signal import BaseSignal
from clusterman_signals.base_signal import SignalResources


class CPUsRequired(BaseSignal):

    def value(self, metrics, timestamp):
        """Each Jolt emits a metric that is the number of cpus required to run
        all of the bundles in a run. This signal sums them up and emits it as
        the required signal. This signal also supports emitting cpus_required
        with a run_id dimension and will take the latest value for each
        run_id and include that in the sum.
        """
        per_run_cpus_required_metric = []
        per_run_cpus_required_run_ids = set()
        no_run_cpus_required_metric = []

        projects_building_metric = []

        for name, time_series in metrics.items():
            _, dims = get_meteorite_identifiers(APP_METRICS, name)

            if name.startswith('cpus_required'):
                if dims and 'run_id' in dims:
                    per_run_cpus_required_metric.append((dims['run_id'], time_series))
                    per_run_cpus_required_run_ids.add(dims['run_id'])
                else:
                    no_run_cpus_required_metric.append(time_series)
            elif name.startswith('building'):
                projects_building_metric.append((dims, time_series))

        cpus_required = sum(
            sum(value for _, value in time_series)
            for time_series in no_run_cpus_required_metric
        )

        self.logger.info(
            f"CPUsRequired: {len(no_run_cpus_required_metric)} time series without run_ids "
            f"contributed {cpus_required} to the total",
        )

        for run_id, time_series in per_run_cpus_required_metric:
            latest_metric = max(time_series, key=itemgetter(0), default=(None, 0))

            # Ignore time series that hasn't been updated in 10 minutes
            if timestamp - latest_metric[0] < self.parameters['cpus_required_staleness_s']:
                cpus_required += latest_metric[1]
                self.logger.info(f"CPUsRequired: {run_id} contributed {latest_metric[1]}")
            else:
                self.logger.info(
                    f"CPUsRequired: {run_id} latest metric was too stale "
                    f"({latest_metric[0]}, delta={timestamp - latest_metric[0]}), would contribute {latest_metric[1]}"
                )

        for dims, time_series in projects_building_metric:
            project = dims.get('project')
            run_id = dims.get('run_id')

            if run_id in per_run_cpus_required_run_ids:
                self.logger.info(
                    f'ProjectsBuilding: Skipping project={project}, run_id={run_id} '
                    'since it exists in CPUsRequired as well',
                )
                continue

            # TODO(RELENG-28264): Make this automagically determined from cpus_required
            cpus_per_build = self.parameters['avg_project_cpus'].get(project, 0)

            project_cpus = sum(value * cpus_per_build for _, value in time_series)
            self.logger.info(f'ProjectsBuilding: Project {project} will need {project_cpus} cpus')
            cpus_required += project_cpus

        return SignalResources(cpus=cpus_required)
