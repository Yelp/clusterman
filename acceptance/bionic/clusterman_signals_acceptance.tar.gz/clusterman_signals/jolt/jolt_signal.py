from operator import itemgetter

from yelp_meteorite import create_gauge
from yelp_meteorite import timeit

from .cpus_required import CPUsRequired
from clusterman_signals.base_signal import BaseSignal
from clusterman_signals.base_signal import SignalResources
from clusterman_signals.clusterman import MostRecentResources


SIGNALS = {
    'last_cpu_usage': MostRecentResources,
    'cpus_required': CPUsRequired,
}


def get_metrics(metrics, prefix):
    return (
        time_series
        for name, time_series in metrics.items()
        if name.startswith(prefix)
    )


class JoltSignal(BaseSignal):

    def __init__(self, logger, parameters):
        super().__init__(logger, parameters)
        self.signals = {
            sig_name: sig_class(logger, parameters)
            for sig_name, sig_class in SIGNALS.items()
        }

        self.metric_emitters = {
            sig_name: create_gauge(
                f'clusterman.jolt_signal.{sig_name}',
                {'pool': self.pool if self.pool else 'jolt'}
            )
            for sig_name in SIGNALS
        }
        self.metric_emitters['combined'] = create_gauge('clusterman.jolt_signal.combined')

    @timeit('clusterman.jolt.signal_run_time')
    def value(self, metrics, timestamp):
        self.logger.info("JoltSignal: start")
        signal_values = {
            sig_name: sig_class.value(metrics, timestamp)
            for sig_name, sig_class in self.signals.items()
        }

        self.logger.info('JoltSignal: Signal values are {}'.format(
            ', '.join((
                f'{name}: {value.cpus} cpus'
                for name, value in signal_values.items()
            ))
        ))

        self.emit_signal_metrics(signal_values)

        # TODO(RELENG-28263): Do smarter things than just max
        cpu_signals = (signal.cpus for signal in signal_values.values() if signal.cpus is not None)
        cpu_signal = max(cpu_signals, default=None)
        if cpu_signal is None:
            self.logger.warning('JoltSignal: No subsignal returned a value')
            return SignalResources(cpus=None)

        cpu_signal = self.constrain_signal(metrics, cpu_signal)
        self.metric_emitters['combined'].set(cpu_signal)
        self.logger.info(f"JoltSignal: Emitting cpus={cpu_signal}")
        return SignalResources(cpus=cpu_signal)

    def constrain_signal(self, metrics, signal):
        orig_signal = signal

        forced_min = next(get_metrics(metrics, 'forced_min'), None)
        if forced_min:
            min_limit = max(forced_min, key=itemgetter(0))[1]
            self.logger.info(f'JoltSignal: Forced min is {min_limit}')
            signal = max(min_limit, signal)

        forced_max = next(get_metrics(metrics, 'forced_max'), None)
        if forced_max:
            max_limit = max(forced_max, key=itemgetter(0))[1]
            self.logger.info(f'JoltSignal: Forced max is {max_limit}')
            signal = min(max_limit, signal)

        if signal != orig_signal:
            self.logger.info(f'JoltSignal: CPU signal constrained {orig_signal}->{signal}')

        return signal

    def emit_signal_metrics(self, signal_values):
        for sig_name, value in signal_values.items():
            if value.cpus is not None:
                self.metric_emitters[sig_name].set(value.cpus)
