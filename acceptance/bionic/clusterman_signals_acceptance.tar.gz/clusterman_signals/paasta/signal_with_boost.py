from clusterman_metrics import generate_key_with_dimensions

from clusterman_signals.base_signal import BaseSignal
from clusterman_signals.base_signal import SignalResources
from clusterman_signals.clusterman.constant_signal import ConstantSignal
from clusterman_signals.clusterman.most_recent_resources import MostRecentResources


class _SignalWithBoost(BaseSignal):
    def __init__(self, logger, parameters, signal_class):
        super().__init__(logger, parameters)
        self.signal = signal_class(logger, parameters)

    def value(self, metrics, timestamp):
        resource_request = self.signal.value(metrics, timestamp)
        boost_key = generate_key_with_dimensions(
            'boost_factor',
            {'cluster': self.cluster, 'pool': self.pool}
        )
        try:
            boost_time, boost_factor = metrics[boost_key][-1]

            # Get the metrics at the time of the boost
            boost_metrics = {key: [v for v in values if v[0] < boost_time] for key, values in metrics.items()}
        except (IndexError, KeyError):
            # No boost factor found in the datastore
            boost_factor = 1
            boost_metrics = metrics
        self.logger.info(f'Requesting {resource_request}, scaled by {boost_factor}')

        boosted_resource_request = self.signal.value(boost_metrics, timestamp) * boost_factor

        return SignalResources(
            cpus=self._get_max_resources(resource_request.cpus, boosted_resource_request.cpus),
            mem=self._get_max_resources(resource_request.mem, boosted_resource_request.mem),
            disk=self._get_max_resources(resource_request.disk, boosted_resource_request.disk),
            # We do not boost GPUs because of cost
            gpus=resource_request.gpus,
        )

    def _get_max_resources(self, *args):
        return max([r for r in args if r is not None], default=None)


class ConstantWithBoost(_SignalWithBoost):
    def __init__(self, logger, parameters):
        super().__init__(logger, parameters, ConstantSignal)


class ResourcesWithBoost(_SignalWithBoost):
    def __init__(self, logger, parameters):
        super().__init__(logger, parameters, MostRecentResources)
