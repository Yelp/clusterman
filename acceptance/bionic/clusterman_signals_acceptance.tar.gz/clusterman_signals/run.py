import logging
import struct
import sys
import traceback
from importlib import import_module
from socket import AF_UNIX
from socket import socket
from typing import Any
from typing import Dict
from typing import Optional

import simplejson as json

from clusterman_signals.base_signal import BaseSignal

SOCK_MESG_SIZE = 4096
SOCK_TIMEOUT_SECONDS = 5
ACK = bytes([1])
ERR = bytes([2])

logger = logging.getLogger(__name__)


class SocketClosedException(Exception):
    pass


class SocketConnectionError(Exception):
    pass


def setup_logging() -> None:
    class MaxLevelFilter(logging.Filter):
        def __init__(self, max_level, name=''):
            super().__init__(name)
            self.max_level = max_level

        def filter(self, record):
            return 1 if record.levelno < self.max_level else 0

    logger.setLevel(logging.DEBUG)

    stdout_handler = logging.StreamHandler(sys.stdout)
    stdout_handler.setLevel(logging.DEBUG)
    stdout_handler.addFilter(MaxLevelFilter(logging.WARNING))
    logger.addHandler(stdout_handler)

    stderr_handler = logging.StreamHandler(sys.stderr)
    stderr_handler.setLevel(logging.WARNING)

    logger.addHandler(stderr_handler)


def listen(signal_namespace: str, signal_name: str, app_name: Optional[str]) -> socket:
    sock = socket(AF_UNIX)
    socket_name = f'\0{signal_namespace}-{signal_name}-'
    if app_name:
        socket_name += f'{app_name}-'
    socket_name += 'socket'
    sock.bind(socket_name)
    sock.listen(1)
    signal_conn, __ = sock.accept()
    return signal_conn


def load_signal(signal_namespace: str, signal_name: str, sock: socket) -> BaseSignal:
    signal_module = import_module(f'clusterman_signals.{signal_namespace}')
    signal_class = getattr(signal_module, signal_name)
    data = json.loads(sock.recv(SOCK_MESG_SIZE))
    params = data.pop('parameters')
    if data:
        logger.warning(f'Extra data passed to signal constructor: {data}; ignoring.')
    return signal_class(logger, params)


def read_signal_input(sock: socket) -> Dict[str, Any]:
    # The first message is the length of the metrics data
    sock.settimeout(None)
    len_bytes = sock.recv(SOCK_MESG_SIZE)
    if not len_bytes:
        raise SocketClosedException('Parent process closed the socket')
    len_metrics = struct.unpack('>I', len_bytes)[0]
    sock.send(ACK)

    # Continue reading from the socket until all the data is read
    sock.settimeout(SOCK_TIMEOUT_SECONDS)
    bytes_received = 0
    data_bytes = bytes()
    while bytes_received < len_metrics:
        msg = sock.recv(SOCK_MESG_SIZE)
        bytes_received += len(msg)
        data_bytes += msg

    logger.info(f'Received {bytes_received} bytes, expected {len_metrics} bytes')
    logger.info(f'Last {len(msg)} bytes received: {msg}')

    # Check to make sure we received the right amount of data
    if bytes_received == len_metrics:
        sock.send(ACK)
    else:
        sock.send(ERR)
        raise SocketConnectionError('Invalid message received; message length {bytes_received} != {len_metrics}')

    return json.loads(data_bytes)


def run_signal(
    signal_namespace: str,
    signal_name: str,
    app_name: Optional[str] = None,
    *args: Any,
) -> int:
    if args:
        logger.warning(f'Extra data passed signal process: {args}; ignoring.')

    setup_logging()
    sock = listen(signal_namespace, signal_name, app_name)
    try:
        signal = load_signal(signal_namespace, signal_name, sock)
    except (ModuleNotFoundError, AttributeError) as e:
        logging.error(f'Signal or module missing, signal not loaded: {str(e)}')
        return 1

    while True:
        try:
            data = read_signal_input(sock)
            metrics = data.pop('metrics')
            timestamp = data.pop('timestamp')
            if data:
                logger.warning(f'Extra data passed to signal constructor: {data}; ignoring.')

            value = signal.value(metrics, timestamp)
            sock.send(json.dumps({'Resources': value}).encode())

        # if the socket was closed by a human or the autoscaler/simulator, shut down cleanly
        except (KeyboardInterrupt, SocketClosedException):
            break

        # otherwise send the traceback to the service process and fail
        except Exception:
            sock.send(traceback.format_exc().encode())
            raise

    return 0


if __name__ == '__main__':
    sys.exit(run_signal(*sys.argv[1:]))
