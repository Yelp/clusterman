import time
from collections import defaultdict
from collections import namedtuple
from pprint import pformat

import requests
import staticconf
from clusterman_metrics.util.constants import APP_METRICS
from clusterman_metrics.util.meteorite import get_meteorite_identifiers

from clusterman_signals.base_signal import BaseSignal
from clusterman_signals.base_signal import SignalResources
from clusterman_signals.paasta.signal_with_boost import _SignalWithBoost

CLUSTERMAN_CONFIG_LOCATION = '/nail/srv/configs/clusterman.yaml'
REQUIRED_RESOURCES = ('disk', 'mem', 'cpus')
SPARK_METRIC_PREFIX = 'requested_'


FrameworkInfo = namedtuple('FrameworkInfo', ['name', 'webui_url'])


class FrameworkSet(object):

    def __init__(self):
        self.names = set()
        self.webui_urls = set()

    def add(self, framework_info):
        if framework_info.name is not None:
            self.names.add(framework_info.name)
        if framework_info.webui_url is not None:
            self.webui_urls.add(framework_info.webui_url)

    def __contains__(self, framework_info):
        if framework_info.webui_url is not None:
            return framework_info.webui_url in self.webui_urls
        else:
            return framework_info.name in self.names


class SparkSignal(BaseSignal):

    def __init__(self, logger, parameters):
        super().__init__(logger, parameters)
        staticconf.YamlConfiguration(CLUSTERMAN_CONFIG_LOCATION)
        self.max_unregistered_framework_age_seconds = parameters['max_unregistered_framework_age_seconds']
        self.verbose = parameters.get('verbose', False)

    def value(self, metrics, timestamp):
        requested_resources_by_framework = self._aggregate_spark_framework_requirements(metrics)

        filtered_requests_by_framework = self._filter_resource_requests(requested_resources_by_framework)
        self.logger.info(f'Frameworks to be included in request: {pformat(filtered_requests_by_framework)}')

        signal_resources = self._sum_resource_requests(filtered_requests_by_framework)
        self.logger.info(f'Total resource requirements: {signal_resources}')

        return signal_resources

    def _aggregate_spark_framework_requirements(self, metrics):
        requested_resources_by_framework = defaultdict(dict)
        for metric_key, time_series in metrics.items():
            metric_name, dimensions = get_meteorite_identifiers(APP_METRICS, metric_key)
            if 'framework_name' in dimensions or 'webui_url' in dimensions:
                framework_info = FrameworkInfo(dimensions.get('framework_name'), dimensions.get('webui_url'))
                requested_resources = requested_resources_by_framework[framework_info]
                resource_type = self._extract_resource_type_from_metric_name(metric_name)

                timestamp, requested_quantity = max(time_series, default=(0, None))
                requested_resources[resource_type] = requested_quantity
                requested_resources['timestamp'] = max(requested_resources.get('timestamp', 0), timestamp)

        return requested_resources_by_framework

    def _extract_resource_type_from_metric_name(self, metric_name):
        base_metric_name = metric_name.split('.')[-1]
        return base_metric_name.replace(SPARK_METRIC_PREFIX, '')

    def _filter_resource_requests(self, requested_resources_by_framework):
        filtered_requests_by_framework = {}
        old_unlisted_framework_requests = {}
        active_frameworks, finished_frameworks = self._get_active_and_finished_frameworks()

        for framework_info, requested_resources in requested_resources_by_framework.items():
            if not all(requested_resources.get(resource_type) is not None for resource_type in REQUIRED_RESOURCES):
                self.logger.info(
                    f'Resource request from {framework_info} does not specify all required resource types. '
                    'Ignoring this request.',
                )
                continue
            elif framework_info in finished_frameworks and framework_info not in active_frameworks:
                self.logger.info(f'{framework_info} is inactive or completed. Ignoring this request.')
                continue
            elif (
                framework_info not in active_frameworks and
                time.time() - requested_resources['timestamp'] > self.max_unregistered_framework_age_seconds
            ):
                old_unlisted_framework_requests[framework_info] = requested_resources
                continue
            else:
                filtered_requests_by_framework[framework_info] = requested_resources

        if self.verbose:
            self.logger.info(
                f'Frameworks not listed as active and older than {self.max_unregistered_framework_age_seconds} '
                f'seconds: {pformat(old_unlisted_framework_requests)}',
            )
        else:
            num_old_unlisted_frameworks = len(old_unlisted_framework_requests)
            self.logger.info(
                f'Ignored requests from {num_old_unlisted_frameworks} frameworks not listed as active and older than '
                f'{self.max_unregistered_framework_age_seconds} seconds.',
            )
        return filtered_requests_by_framework

    def _get_active_and_finished_frameworks(self):
        frameworks_response = self._get_frameworks()
        active_frameworks = FrameworkSet()
        finished_frameworks = FrameworkSet()

        for framework in frameworks_response['frameworks']:
            framework_info = FrameworkInfo(framework['name'], framework['webui_url'])
            if framework['active']:
                active_frameworks.add(framework_info)
            else:
                finished_frameworks.add(framework_info)

        for framework in frameworks_response['completed_frameworks']:
            finished_frameworks.add(FrameworkInfo(framework['name'], framework['webui_url']))

        return active_frameworks, finished_frameworks

    def _get_frameworks(self):
        mesos_master_fqdn = staticconf.read_string(f'mesos_clusters.{self.cluster}.fqdn')
        url = f'http://{mesos_master_fqdn}:5050/master/frameworks'
        response = requests.post(url)
        return response.json()

    def _sum_resource_requests(self, requested_resources_by_framework):
        cpus = mem = disk = gpus = 0
        for requested_resources in requested_resources_by_framework.values():
            cpus += requested_resources['cpus']
            mem += requested_resources['mem']
            disk += requested_resources['disk']
            gpus += requested_resources.get('gpus') or 0

        return SignalResources(cpus=cpus, mem=mem, disk=disk, gpus=gpus)


class SparkSignalWithBoost(_SignalWithBoost):
    def __init__(self, logger, parameters):
        super().__init__(logger, parameters, SparkSignal)
