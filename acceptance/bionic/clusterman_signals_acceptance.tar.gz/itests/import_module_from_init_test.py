import importlib
import importlib.util
import inspect
import os

from clusterman_signals.base_signal import BaseSignal


def test_import_module_from_init():

    basedir = 'clusterman_signals'
    apps = [name for name in os.listdir(basedir) if os.path.isdir(os.path.join(basedir, name))]
    for app in apps:
        class_set = set()
        module_set = set()
        for path, dirs, files in os.walk(os.path.join(basedir, app)):
            if '__pycache__' in path:
                continue

            for f in files:
                if f[-3:] != '.py' or f == '__init__.py':
                    continue

                full_path = os.path.join(path, f)
                module_name = full_path.replace('/', '.')[:-3]
                module = __import__(module_name, fromlist=[""])

                class_set |= {
                    name
                    for name, __ in inspect.getmembers(
                        module,
                        lambda x: inspect.isclass(x) and x.__module__ == module.__name__ and issubclass(x, BaseSignal),
                    )
                    if name[0] != '_'
                }

        module = importlib.import_module(f'{basedir}.{app}')
        for name, obj in inspect.getmembers(module):
            if inspect.isclass(obj):
                module_set.add(name)

        assert class_set == module_set
