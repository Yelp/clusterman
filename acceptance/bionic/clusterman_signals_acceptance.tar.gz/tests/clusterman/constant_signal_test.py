from unittest.mock import Mock

import pytest

from clusterman_signals.base_signal import SignalResources
from clusterman_signals.clusterman.constant_signal import ConstantSignal


@pytest.fixture
def signal():
    return ConstantSignal(Mock(), {})


def test_always_none(signal):
    assert signal.value({}, 1234) == SignalResources(cpus=None)
