import arrow
import mock
import pytest

from clusterman_signals.base_signal import SignalResources
from clusterman_signals.clusterman.most_recent_resources import MostRecentResources


@pytest.fixture
def most_recent_resources():
    return MostRecentResources(mock.Mock(), {})


def test_most_recent_values(most_recent_resources):
    metrics = {
        'cpus_allocated': [(arrow.now().timestamp, 150), (arrow.now().shift(seconds=-59).timestamp, 250)],
        'mem_allocated': [(arrow.now().timestamp, 1000), (arrow.now().shift(seconds=-59).timestamp, 1250)],
        'disk_allocated': [(arrow.now().timestamp, 500), (arrow.now().shift(seconds=-59).timestamp, 600)],
        'gpus_allocated': [(arrow.now().timestamp, None), (arrow.now().shift(seconds=-59).timestamp, 0)],
    }
    assert most_recent_resources.value(metrics, 1234) == SignalResources(cpus=150, mem=1000, disk=500)


def test_most_recent_values_without_gpus(most_recent_resources):
    metrics = {
        'cpus_allocated': [(arrow.now().timestamp, 150), (arrow.now().shift(seconds=-59).timestamp, 250)],
        'mem_allocated': [(arrow.now().timestamp, 1000), (arrow.now().shift(seconds=-59).timestamp, 1250)],
        'disk_allocated': [(arrow.now().timestamp, 500), (arrow.now().shift(seconds=-59).timestamp, 600)],
    }
    assert most_recent_resources.value(metrics, 1234) == SignalResources(cpus=150, mem=1000, disk=500)


def test_empty_metric_cache(most_recent_resources):
    metrics = {'cpus_allocated': [], 'mem_allocated': [], 'disk_allocated': [], 'gpus_allocated': []}
    assert most_recent_resources.value(metrics, 1234) == SignalResources()
