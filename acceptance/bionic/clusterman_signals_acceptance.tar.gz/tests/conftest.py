import pytest
import yelp_meteorite


@pytest.yield_fixture(autouse=True, scope='session')
def meteorite():
    with yelp_meteorite.testcase():
        yield
