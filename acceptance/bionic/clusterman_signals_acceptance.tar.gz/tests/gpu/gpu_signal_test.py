import mock

from clusterman_signals.base_signal import SignalResources
from clusterman_signals.gpu.gpu_signal import GPUSignal


@mock.patch('clusterman_signals.spark.SparkSignal.value')
@mock.patch('clusterman_signals.gpu.MarathonGPUSignal.value')
@mock.patch('clusterman_signals.gpu.MarathonGPUSignal._get_marathon_clients', mock.Mock())
def test_gpu_signal(
    fake_marathon_gpu_signal_value,
    fake_spark_signal_value,
):
    gpu_signal = GPUSignal(
        mock.Mock(),
        {
            'cluster': 'fake-cluster',
            'pool': 'fake-pool',
            'max_unregistered_framework_age_seconds': 60,
        }
    )
    fake_marathon_gpu_signal_value.return_value = SignalResources(gpus=4)
    fake_spark_signal_value.return_value = SignalResources(cpus=800, gpus=16)

    assert gpu_signal.value(mock.Mock(), 1234) == SignalResources(gpus=20)
