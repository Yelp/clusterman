import mock
import pytest

from clusterman_signals.base_signal import SignalResources
from clusterman_signals.jenkins import JenkinsSignal
from clusterman_signals.jenkins.jenkins_signal import decide_scaling
from clusterman_signals.jenkins.jenkins_signal import extract_cpus_available_per_host
from clusterman_signals.jenkins.jenkins_signal import ScalingDecision


@pytest.fixture
def signal():
    params = {
        'constraints': [
            {'cpus_per_slot': 4, 'slots_required': 1},
        ],
        'host_size': 15,
    }
    return JenkinsSignal(mock.Mock(), params)


def test_jenkins_signal_no_scale_up(signal):
    metrics = {
        'cpus_available|pool=test,host=host1': [(1518042132, 8)],
        'cpus_allocated': [(1518042132, 7)],
        'mem_allocated': [(1518042132, 1)],
        'disk_allocated': [(1518042132, 1)],
        'gpus_allocated': [(1518042132, 1)],
    }

    assert signal.value(metrics, 1234) == SignalResources(cpus=15, mem=1, disk=1, gpus=1)


def test_jenkins_signal_scale_up(signal):
    metrics = {
        'cpus_available|pool=test,host=host1': [(1518042132, 3)],
        'cpus_allocated': [(1518042132, 12)],
        'mem_allocated': [(1518042132, 1)],
        'disk_allocated': [(1518042132, 1)],
        'gpus_allocated': [(1518042132, 1)],
    }

    assert signal.value(metrics, 1234) == SignalResources(cpus=30, mem=1, disk=1, gpus=1)


def test_extract_cpus_available_per_host_use_latest():
    metrics = {
        'cpus_available|pool=test,host=host1': [(0, 3), (1, 4)],
    }
    assert extract_cpus_available_per_host(metrics) == {'host1': 4}


def test_extract_cpus_available_per_host_multi_host():
    metrics = {
        'cpus_available|pool=test,host=host1': [(0, 4)],
        'cpus_available|pool=test,host=host2': [(1, 8)],
    }
    expected = {'host1': 4, 'host2': 8}
    assert extract_cpus_available_per_host(metrics) == expected


def test_extract_cpus_available_per_host_ignore_other_metrics():
    metrics = {
        'cpus_available|pool=test,host=host1': [(0, 4)],
        'cpus_allocated': [(1518042132, 15)],
    }
    assert extract_cpus_available_per_host(metrics) == {'host1': 4}


def test_decide_scaling_no_scale_up_simple():
    constraints = [{'cpus_per_slot': 4, 'slots_required': 1}]
    host_to_cpus_avail = {'host1': 4}

    assert decide_scaling(host_to_cpus_avail, constraints) == ScalingDecision.HOLD


def test_decide_scaling_scale_up_simple():
    constraints = [{'cpus_per_slot': 4, 'slots_required': 1}]
    host_to_cpus_avail = {'host1': 2}

    assert decide_scaling(host_to_cpus_avail, constraints) == ScalingDecision.UP


def test_decide_scaling_scale_up_multi_slot_diff_host():
    constraints = [{'cpus_per_slot': 4, 'slots_required': 2}]
    host_to_cpus_avail = {'host1': 4, 'host2': 2}

    assert decide_scaling(host_to_cpus_avail, constraints) == ScalingDecision.UP


def test_decide_scaling_scale_up_multi_slot_same_host():
    constraints = [{'cpus_per_slot': 4, 'slots_required': 2}]
    host_to_cpus_avail = {'host1': 8}

    assert decide_scaling(host_to_cpus_avail, constraints) == ScalingDecision.HOLD


def test_decide_scaling_scale_up_multi_constraint_one_pass():
    constraints = [
        {'cpus_per_slot': 4, 'slots_required': 2},
        {'cpus_per_slot': 8, 'slots_required': 1},
    ]
    host_to_cpus_avail = {'host1': 6, 'host2': 4}

    assert decide_scaling(host_to_cpus_avail, constraints) == ScalingDecision.UP


def test_decide_scaling_hold_multi_constraint_one_pass():
    constraints = [
        {'cpus_per_slot': 4, 'slots_required': 2},
        {'cpus_per_slot': 8, 'slots_required': 1},
    ]
    host_to_cpus_avail = {'host1': 8, 'host2': 4}

    assert decide_scaling(host_to_cpus_avail, constraints) == ScalingDecision.HOLD


def test_decide_scaling_scale_down():
    constraints = [{'cpus_per_slot': 4, 'slots_required': 2}]
    host_to_cpus_avail = {'host1': 8, 'host2': 8}

    assert decide_scaling(host_to_cpus_avail, constraints) == ScalingDecision.DOWN


def test_decide_scaling_scale_hold_extra_slots_same_host():
    constraints = [{'cpus_per_slot': 4, 'slots_required': 2}]
    host_to_cpus_avail = {'host1': 16}

    assert decide_scaling(host_to_cpus_avail, constraints) == ScalingDecision.HOLD
