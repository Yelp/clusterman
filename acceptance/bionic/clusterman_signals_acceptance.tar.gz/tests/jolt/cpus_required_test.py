import mock
import pytest

from clusterman_signals.base_signal import SignalResources
from clusterman_signals.jolt import CPUsRequired


@pytest.fixture
def signal():
    return CPUsRequired(
        mock.Mock(),
        {'cpus_required_staleness_s': 600, 'avg_project_cpus': {'yelp-main': 10, 'apollo': 2}},
    )


def test_has_metrics(signal):
    metrics = {'cpus_required': [(0, 1), (1, 4), (2, 2)]}
    assert signal.value(metrics, 1234) == SignalResources(cpus=7)


def test_no_metrics(signal):
    assert signal.value({'cpus_required': []}, 1234) == SignalResources(cpus=0)


def test_run_id_metrics(signal):
    metrics = {
        'cpus_required': [(0, 1), (1, 4), (2, 2)],
        'cpus_required|run_id=1': [(0, 1), (1, 4), (2, 2)],
        'cpus_required|run_id=2': [(0, 3), (1, 2), (2, 1)],
    }
    assert signal.value(metrics, 3) == SignalResources(cpus=10)


def test_pool_metrics(signal):
    metrics = {
        'cpus_required|pool=test': [(0, 1), (1, 4), (2, 2)],
        'cpus_required|pool=test,run_id=1': [(0, 1), (1, 4), (2, 2)],
        'cpus_required|pool=test,run_id=2': [(0, 3), (1, 2), (2, 1)],
    }
    assert signal.value(metrics, 3) == SignalResources(cpus=10)


def test_projects_building(signal):
    metrics = {
        'building|project=apollo': [(1518042132, 1), (1518042132, 4), (1518042132, 2)],
        'building|project=yelp-main': [(1518042132, 5), (1518042132, 3)],
    }
    assert signal.value(metrics, 1234) == SignalResources(cpus=94)


def test_projects_no_avg(signal):
    metrics = {
        'building|project=not_a_project': [(1518042132, 1), (1518042132, 4), (1518042132, 2)],
    }
    assert signal.value(metrics, 1234) == SignalResources(cpus=0)


def test_no_building_metrics(signal):
    assert signal.value({'not_a_building_signal': []}, 1234) == SignalResources(cpus=0)


def test_cpus_required_ignores_projects_building(signal):
    assert signal.value(
        {
            'cpus_required|run_id=1': [(5, 1), (6, 4), (7, 2)],
            'building|project=yelp-main,run_id=1': [(0, 3)],
        }, 4) == SignalResources(cpus=2)
