import mock
import pytest

from clusterman_signals.base_signal import SignalResources
from clusterman_signals.jolt import JoltSignal


@pytest.fixture
def signal():
    return JoltSignal(mock.Mock(), {'avg_project_cpus': {'apollo': 25}, 'cpus_required_staleness_s': 600})


def test_has_metrics(signal):
    metrics = {
        'cpus_required': [(1518042132, 1)],
        'building|project=apollo': [(1518042132, 2)],
        'cpus_allocated': [(1518042132, 150)],
        'mem_allocated': [(1518042132, 10000)],
        'disk_allocated': [(1518042132, 2000)],
        'gpus_allocated': [],
    }
    assert signal.value(metrics, 1234) == SignalResources(cpus=150)


def test_has_empty_metric(signal):
    metrics = {
        'cpus_required': [(1518042132, 1)],
        'building|project=apollo': [(1518042132, 2)],
        'cpus_allocated': [(1518042132, 150)],
        'mem_allocated': [(1518042132, 10000)],
        'disk_allocated': [(1518042132, 2000)],
        'gpus_allocated': [],
        'forced_min': [],
    }
    assert signal.value(metrics, 1234) == SignalResources(cpus=150)


def test_max_constrain(signal):
    metrics = {
        'cpus_required': [(1518042132, 1)],
        'building|project=apollo': [(1518042132, 2)],
        'cpus_allocated': [(1518042132, 150)],
        'mem_allocated': [(1518042132, 10000)],
        'disk_allocated': [(1518042132, 2000)],
        'gpus_allocated': [],
        'forced_max': [(0, 200), (1518042132, 100)],
    }
    assert signal.value(metrics, 1234) == SignalResources(cpus=100)


def test_min_constrain(signal):
    metrics = {
        'cpus_required': [(1518042132, 1)],
        'building|project=apollo': [(1518042132, 2)],
        'cpus_allocated': [(1518042132, 150)],
        'mem_allocated': [(1518042132, 10000)],
        'disk_allocated': [(1518042132, 2000)],
        'gpus_allocated': [],
        'forced_min': [(0, 200), (1518042132, 300)],
    }
    assert signal.value(metrics, 1234) == SignalResources(cpus=300)


def test_max_constrain_pool(signal):
    metrics = {
        'cpus_required': [(1518042132, 1)],
        'building|project=apollo': [(1518042132, 2)],
        'cpus_allocated': [(1518042132, 150)],
        'mem_allocated': [(1518042132, 10000)],
        'disk_allocated': [(1518042132, 2000)],
        'gpus_allocated': [],
        'forced_max|pool=test': [(0, 200), (1518042132, 100)],
    }
    assert signal.value(metrics, 1234) == SignalResources(cpus=100)


def test_min_constrain_pool(signal):
    metrics = {
        'cpus_required': [(1518042132, 1)],
        'building|project=apollo': [(1518042132, 2)],
        'cpus_allocated': [(1518042132, 150)],
        'mem_allocated': [(1518042132, 10000)],
        'disk_allocated': [(1518042132, 2000)],
        'gpus_allocated': [],
        'forced_min|pool=test': [(0, 200), (1518042132, 300)],
    }
    assert signal.value(metrics, 1234) == SignalResources(cpus=300)
