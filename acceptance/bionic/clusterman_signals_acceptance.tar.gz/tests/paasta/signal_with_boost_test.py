import mock
import pytest

from clusterman_signals.base_signal import SignalResources
from clusterman_signals.paasta.signal_with_boost import _SignalWithBoost
from clusterman_signals.paasta.signal_with_boost import ConstantWithBoost


@pytest.fixture
def metrics():
    return {
        'cpus_allocated': [(100, 50), (1100, 150)],
        'mem_allocated': [(100, 700), (1100, 1000)],
        'disk_allocated': [(100, 200), (1100, 500)],
    }


@pytest.fixture
def signal_with_boost(metrics):
    fake_signal = mock.Mock()
    fake_signal.return_value.value.return_value = SignalResources(cpus=150, mem=1000, disk=500)
    return _SignalWithBoost(mock.Mock(), {'cluster': 'fake-cluster', 'pool': 'fake-pool'}, fake_signal)


def test_no_boost(signal_with_boost, metrics):
    assert signal_with_boost.value(metrics, 1234) == SignalResources(cpus=150, mem=1000, disk=500)


def test_with_recent_boost(signal_with_boost, metrics):
    metrics['boost_factor|cluster=fake-cluster,pool=fake-pool'] = [(1120, 1.5)]
    assert signal_with_boost.value(metrics, 1234) == SignalResources(cpus=225, mem=1500, disk=750)


def test_with_old_boost(signal_with_boost, metrics):
    signal_with_boost.signal.value.side_effect = [
        SignalResources(cpus=400, mem=100, disk=300),
        SignalResources(cpus=150, mem=1000, disk=500),
    ]
    metrics['boost_factor|cluster=fake-cluster,pool=fake-pool'] = [(1120, 1.5)]
    assert signal_with_boost.value(metrics, 1234) == SignalResources(cpus=400, mem=1500, disk=750)


def test_with_multiple_boosts(signal_with_boost, metrics):
    metrics['boost_factor|cluster=fake-cluster,pool=fake-pool'] = [(1120, 1.5), (1220, 2)]
    assert signal_with_boost.value(metrics, 1234) == SignalResources(cpus=300, mem=2000, disk=1000)


def test_constant_with_boost_no_boost():
    signal = ConstantWithBoost(mock.Mock(), {'cluster': 'fake-cluster', 'pool': 'fake-pool', 'cpus': 10})
    assert signal.value({}, 1234) == SignalResources(cpus=10)


def test_constant_with_boost_with_boost():
    metrics = {'boost_factor|cluster=fake-cluster,pool=fake-pool': [(1120, 1.5)]}
    signal = ConstantWithBoost(mock.Mock(), {'cluster': 'fake-cluster', 'pool': 'fake-pool', 'cpus': 10})
    assert signal.value(metrics, 1234) == SignalResources(cpus=15)


def test_none_resources(signal_with_boost, metrics):
    metrics['boost_factor|cluster=fake-cluster,pool=fake-pool'] = [(120, 1.5)]
    signal_with_boost.signal.value.side_effect = [
        SignalResources(cpus=None, mem=300, disk=None),
        SignalResources(cpus=400, mem=None, disk=None),
    ]
    assert signal_with_boost.value(metrics, 1234) == SignalResources(cpus=600, mem=300, disk=None)


def test_all_resources_0(signal_with_boost, metrics):
    signal_with_boost.signal.value.return_value = SignalResources(cpus=0, mem=0, disk=0)
    assert signal_with_boost.value(metrics, 1234) == SignalResources(cpus=0, mem=0, disk=0)
