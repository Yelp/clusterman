import mock
import pytest
import simplejson as json

from clusterman_signals.run import listen
from clusterman_signals.run import load_signal
from clusterman_signals.run import logger
from clusterman_signals.run import read_signal_input
from clusterman_signals.run import run_signal
from clusterman_signals.run import setup_logging
from clusterman_signals.run import SocketClosedException
from clusterman_signals.run import SocketConnectionError


def test_logging(capsys):
    setup_logging()
    logger.info('foo')
    logger.warning('bar')
    output = capsys.readouterr()
    assert output.out == 'foo\n'
    assert output.err == 'bar\n'


@mock.patch('clusterman_signals.run.socket')
@pytest.mark.parametrize('app_name', [None, 'myapp'])
def test_listen(mock_socket, app_name):
    mock_socket.return_value.accept.return_value = (mock.Mock(), mock.Mock())
    listen('foo', 'bar', app_name)
    expected_socket_name = '\0foo-bar-myapp-socket' if app_name else '\0foo-bar-socket'
    assert mock_socket.return_value.bind.call_args == mock.call(expected_socket_name)


@mock.patch('clusterman_signals.run.import_module')
def test_load_signal(mock_import):
    mock_sock = mock.Mock()
    mock_sock.recv.return_value = '{"parameters": {"asdf": "hjkl"}}'
    with mock.patch('clusterman_signals.run.logger') as mock_logger:
        load_signal('foo', 'bar', mock_sock)
        assert mock_import.call_args == mock.call('clusterman_signals.foo')
        signal_class = mock_import.return_value.bar
        assert signal_class.call_args == mock.call(mock_logger, {'asdf': 'hjkl'})


def test_read_signal_input_connection_closed():
    mock_sock = mock.Mock()
    mock_sock.recv.return_value = None
    with pytest.raises(SocketClosedException):
        read_signal_input(mock_sock)


@mock.patch('clusterman_signals.run.SOCK_MESG_SIZE', 4)
@mock.patch('clusterman_signals.run.logger', mock.Mock())
class TestReadMetrics:
    def test_read_signal_input_data_len_invalid(self):
        mock_sock = mock.Mock()
        metrics = {'metrics': {'foo': 'bar'}}
        metrics_bytes = json.dumps(metrics).encode()
        mock_sock.recv.side_effect = [bytes([0, 0, 0, len(metrics_bytes) - 2])] + \
            [metrics_bytes[i:i + 2] for i in range(0, len(metrics_bytes), 2)]
        with pytest.raises(SocketConnectionError):
            read_signal_input(mock_sock)

    def test_read_signal_input_data(self):
        mock_sock = mock.Mock()
        metrics = {'metrics': {'foo': 'bar'}}
        metrics_bytes = json.dumps(metrics).encode()
        mock_sock.recv.side_effect = [bytes([0, 0, 0, len(metrics_bytes)])] + \
            [metrics_bytes[i:i + 2] for i in range(0, len(metrics_bytes), 2)]
        value = read_signal_input(mock_sock)
        assert value == metrics


@mock.patch('clusterman_signals.run.setup_logging')
@mock.patch('clusterman_signals.run.listen')
@mock.patch('clusterman_signals.run.read_signal_input')
class TestRunSignal:
    def test_run_signal(self, mock_read_signal_input, mock_listen, mock_logging):
        mock_read_signal_input.side_effect = [{'metrics': [(1, 2)], 'timestamp': 1234, 'a': 2}, SocketClosedException]
        with mock.patch('clusterman_signals.run.load_signal'), \
                mock.patch('clusterman_signals.run.logger') as mock_logger:
            run_signal('foo', 'bar')
            assert mock_logger.warning.call_count == 1
        assert mock_read_signal_input.call_count == 2
        assert mock_listen.return_value.send.call_count == 1

    def test_run_signal_error(self, mock_read_signal_input, mock_listen, mock_logging):
        mock_read_signal_input.side_effect = [
            {'metrics': [(1, 2)], 'timestamp': 1234},
            Exception('Socket could not communicate'),
        ]
        with mock.patch('clusterman_signals.run.load_signal'), pytest.raises(Exception):
            run_signal('foo', 'bar')
        assert mock_read_signal_input.call_count == 2
        assert mock_listen.return_value.send.call_count == 2

    def test_run_signal_no_module(self, mock_read_signal_input, mock_listen, mock_logging):
        with mock.patch('clusterman_signals.run.load_signal', side_effect=ModuleNotFoundError()):
            assert run_signal('foo', 'bar') == 1
        assert mock_read_signal_input.call_count == 0
