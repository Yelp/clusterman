import mock
import pytest
from clusterman_metrics import generate_key_with_dimensions

from clusterman_signals.base_signal import SignalResources
from clusterman_signals.spark.spark_signal import SPARK_METRIC_PREFIX
from clusterman_signals.spark.spark_signal import SparkSignal


@pytest.fixture
def spark_signal():
    with mock.patch.object(SparkSignal, '_get_frameworks'):
        parameters = {
            'paasta_cluster': 'anywhere-prod',
            'max_unregistered_framework_age_seconds': 60,
        }
        yield SparkSignal(mock.Mock(), parameters)


@pytest.fixture(autouse=True)
def mock_time():
    with mock.patch('time.time', return_value=1000):
        yield


def construct_metrics_for_framework(name, cpus, mem, disk, gpus=0,
                                    webui_url=None, assign_webui_url=True, timestamp=999):
    dimensions = {'framework_name': name}

    if webui_url is None and assign_webui_url:
        webui_url = f'http://{name}.com:222'

    if webui_url:
        dimensions['webui_url'] = webui_url

    result = {}
    if cpus is not None:
        result[generate_key_with_dimensions(f'{SPARK_METRIC_PREFIX}cpus', dimensions)] = [(timestamp, cpus)]
    if mem is not None:
        result[generate_key_with_dimensions(f'{SPARK_METRIC_PREFIX}mem', dimensions)] = [(timestamp, mem)]
    if disk is not None:
        result[generate_key_with_dimensions(f'{SPARK_METRIC_PREFIX}disk', dimensions)] = [(timestamp, disk)]
    if gpus is not None:
        result[generate_key_with_dimensions(f'{SPARK_METRIC_PREFIX}gpus', dimensions)] = [(timestamp, gpus)]

    return result


class TestMainCase:

    @pytest.fixture
    def spark_signal(self, spark_signal):
        spark_signal._get_frameworks.return_value = {
            'frameworks': [
                {
                    'name': 'active_framework',
                    'webui_url': 'http://active_framework.com:222',
                    'active': True,
                },
                {
                    'name': 'inactive_framework',
                    'webui_url': 'http://inactive_framework.com:222',
                    'active': False,
                },
                {
                    'name': 'reregistered_framework',
                    'webui_url': 'http://reregistered_framework.com:222',
                    'active': True,
                },
            ],
            'completed_frameworks': [
                {
                    'name': 'completed_framework',
                    'webui_url': 'http://completed_framework.com:222',
                },
                {
                    'name': 'reregistered_framework',
                    'webui_url': 'http://reregistered_framework.com:222',
                }
            ],
        }

        return spark_signal

    def test_get_completed_and_inactive_frameworks(self, spark_signal):
        active_frameworks, finished_frameworks = spark_signal._get_active_and_finished_frameworks()
        assert active_frameworks.names == {'active_framework', 'reregistered_framework'}
        assert finished_frameworks.names == {'inactive_framework', 'completed_framework', 'reregistered_framework'}

    def test_active_framework(self, spark_signal):
        metrics = construct_metrics_for_framework('active_framework', cpus=45, mem=2000, disk=1000)
        assert spark_signal.value(metrics, 1234) == SignalResources(cpus=45, mem=2000, disk=1000, gpus=0)

    def test_recent_unregistered_framework(self, spark_signal):
        metrics = construct_metrics_for_framework(
            'unregistered_framework',
            cpus=45,
            mem=2000,
            disk=1000,
            timestamp=950,
        )
        assert spark_signal.value(metrics, 1234) == SignalResources(cpus=45, mem=2000, disk=1000, gpus=0)

    def test_old_unregistered_framework(self, spark_signal):
        metrics = construct_metrics_for_framework(
            'unregistered_framework',
            cpus=45,
            mem=2000,
            disk=1000,
            timestamp=500,
        )
        assert spark_signal.value(metrics, 1234) == SignalResources(cpus=0, mem=0, disk=0, gpus=0)

    def test_incomplete_requests(self, spark_signal):
        metrics = construct_metrics_for_framework('active_framework', cpus=None, mem=2000, disk=1000)
        assert spark_signal.value(metrics, 1234) == SignalResources(cpus=0, mem=0, disk=0, gpus=0)

        metrics = construct_metrics_for_framework('active_framework', cpus=45, mem=None, disk=1000)
        assert spark_signal.value(metrics, 1234) == SignalResources(cpus=0, mem=0, disk=0, gpus=0)

        metrics = construct_metrics_for_framework('active_framework', cpus=45, mem=2000, disk=None)
        assert spark_signal.value(metrics, 1234) == SignalResources(cpus=0, mem=0, disk=0, gpus=0)

    def test_gpus_are_optional(self, spark_signal):
        metrics = construct_metrics_for_framework('active_framework', cpus=45, mem=2000, disk=1000, gpus=None)
        assert spark_signal.value(metrics, 1234) == SignalResources(cpus=45, mem=2000, disk=1000, gpus=0)

    def test_inactive_framework(self, spark_signal):
        metrics = construct_metrics_for_framework('inactive_framework', cpus=45, mem=2000, disk=1000, gpus=1)
        assert spark_signal.value(metrics, 1234) == SignalResources(cpus=0, mem=0, disk=0, gpus=0)

    def test_completed_framework(self, spark_signal):
        metrics = construct_metrics_for_framework('completed_framework', cpus=45, mem=2000, disk=1000, gpus=4)
        assert spark_signal.value(metrics, 1234) == SignalResources(cpus=0, mem=0, disk=0, gpus=0)

    @pytest.mark.parametrize('assign_webui_url', [True, False])
    def test_multiple_frameworks_and_(self, spark_signal, assign_webui_url):
        metrics = construct_metrics_for_framework(
            'active_framework',
            cpus=45,
            mem=2000,
            disk=1000,
            gpus=2,
            assign_webui_url=assign_webui_url,
        )
        metrics.update(
            construct_metrics_for_framework(
                'unregistered_framework',
                cpus=30,
                mem=1500,
                disk=2000,
                assign_webui_url=assign_webui_url,
            )
        )
        metrics.update(
            construct_metrics_for_framework(
                'inactive_framework',
                cpus=1000,
                mem=10000,
                disk=50000,
                assign_webui_url=assign_webui_url,
            )
        )

        assert spark_signal.value(metrics, 1234) == SignalResources(
            cpus=45 + 30,
            mem=2000 + 1500,
            disk=1000 + 2000,
            gpus=2
        )

    def test_framework_listed_as_active_and_inactive(self, spark_signal):
        metrics = construct_metrics_for_framework('reregistered_framework', cpus=12, mem=1000, disk=1000)
        assert spark_signal.value(metrics, 1234) == SignalResources(cpus=12, mem=1000, disk=1000, gpus=0)


def test_frameworks_with_same_name_different_webui_url(spark_signal):
    spark_signal._get_frameworks.return_value = {
        'frameworks': [
            {
                'name': 'framework1',
                'webui_url': 'http://framework1.com:222',
                'active': True,
            },
            {
                'name': 'framework1',
                'webui_url': 'http://framework2.com:222',
                'active': True,
            },
        ],
        'completed_frameworks': [],
    }

    metrics = construct_metrics_for_framework(
        'framework1',
        cpus=10,
        mem=1000,
        disk=1000,
        webui_url='http://framework1.com:222',
    )
    metrics.update(
        construct_metrics_for_framework(
            'framework1',
            cpus=25,
            mem=2500,
            disk=2500,
            webui_url='http://framework2.com:222',
        )
    )

    assert spark_signal.value(metrics, 1234) == SignalResources(cpus=35, mem=3500, disk=3500, gpus=0)
