from clusterman_signals.base_signal import BaseSignal
from clusterman_signals.base_signal import SignalResources


class ConstantSignal(BaseSignal):
    """This signal allows the autoscaler to clean up extra fulfilled capacity
    without changing the target capacity.
    """

    def value(self, metrics, timestamp):
        cpus = self.parameters.get('cpus', None)
        mem = self.parameters.get('mem', None)
        disk = self.parameters.get('disk', None)
        gpus = self.parameters.get('gpus', None)
        return SignalResources(cpus=cpus, mem=mem, disk=disk, gpus=gpus)
