from .marathon_gpu_signal import MarathonGPUSignal
from clusterman_signals.base_signal import BaseSignal
from clusterman_signals.base_signal import SignalResources
from clusterman_signals.spark import SparkSignal


SIGNALS = {
    'SparkSignal': SparkSignal,
    'MarathonGPUSignal': MarathonGPUSignal,
}


class GPUSignal(BaseSignal):

    def __init__(self, logger, parameters):
        super().__init__(logger, parameters)
        self.signals = {
            sig_name: sig_class(logger, parameters)
            for sig_name, sig_class in SIGNALS.items()
        }

    def value(self, metrics, timestamp):
        signal_values = {
            sig_name: sig.value(metrics, timestamp)
            for sig_name, sig in self.signals.items()
        }

        return SignalResources(
            gpus=sum(signal.gpus for signal in signal_values.values() if signal.gpus is not None)
        )
