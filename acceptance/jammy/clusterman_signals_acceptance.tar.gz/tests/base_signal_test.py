import mock
import pytest

from clusterman_signals.base_signal import BaseSignal
from clusterman_signals.base_signal import SignalResources


class AlphaSignal(BaseSignal):
    def value(self, metrics, timestamp):
        return SignalResources(cpus=1.0, mem=0.5, disk=None)


@pytest.fixture
def alpha_parameters():
    return dict(
        cluster='fake_cluster',
        pool='fake_pool',
        param_A=10,
    )


@pytest.fixture
def alpha_signal(alpha_parameters):
    return AlphaSignal(mock.Mock(), alpha_parameters)


def test_init(alpha_signal, alpha_parameters):
    assert alpha_signal.cluster == 'fake_cluster'
    assert alpha_signal.pool == 'fake_pool'
    assert alpha_signal.parameters == alpha_parameters


def test_value(alpha_signal):
    assert alpha_signal.value({}, 1234) == SignalResources(cpus=1.0, mem=0.5, disk=None)


def test_signal_resources_multiplication_all_zero():
    assert SignalResources(cpus=0, mem=0, disk=0, gpus=0) * 1 == SignalResources(cpus=0, mem=0, disk=0, gpus=0)
