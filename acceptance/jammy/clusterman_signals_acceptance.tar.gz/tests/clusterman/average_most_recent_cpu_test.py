import arrow
import mock
import pytest

from clusterman_signals.base_signal import SignalResources
from clusterman_signals.clusterman.average_most_recent_cpu import AverageMostRecentCPU


@pytest.fixture
def average_most_recent_cpu():
    return AverageMostRecentCPU(mock.Mock(), {})


def test_average_recent_cpu_value(average_most_recent_cpu):
    metrics = {'cpus_allocated': [
        (arrow.now().timestamp, 150),
        (arrow.now().shift(seconds=-60).timestamp, 250),
        (arrow.now().shift(seconds=-120).timestamp, 200),
        (arrow.now().shift(seconds=-180).timestamp, 250),
        (arrow.now().shift(seconds=-240).timestamp, 350)
    ]}
    assert average_most_recent_cpu.value(metrics, 1234) == SignalResources(cpus=240)


def test_empty_metric_cache(average_most_recent_cpu):
    metrics = {'cpus_allocated': []}
    assert average_most_recent_cpu.value(metrics, 1234) == SignalResources()
