import marathon
import mock
import requests_mock

from clusterman_signals.base_signal import SignalResources
from clusterman_signals.gpu.marathon_gpu_signal import MarathonGPUSignal


@mock.patch('marathon.MarathonClient', autospec=True)
def test_marathon_gpu_signal_get_marathon_clients(mock_client):
    bad_client = mock.Mock()
    bad_client.ping = mock.Mock(side_effect=marathon.exceptions.InternalServerError(mock.MagicMock()))
    mock_client.side_effect = [mock.MagicMock(), bad_client]

    # init function runs _get_marathon_clients
    marathon_gpu_signal = MarathonGPUSignal(mock.Mock(), {'cluster': 'pnw-devc'})

    assert len(marathon_gpu_signal.clients) == 1
    assert mock_client.call_args_list == [
        mock.call('http://marathon.paasta-pnw-devc.yelp'),
        mock.call('http://marathon1.paasta-pnw-devc.yelp'),
    ]


@mock.patch.object(MarathonGPUSignal, '_get_marathon_clients', autospec=True)
def test_marathon_gpu_signal(mock_get_clients):
    mock_get_clients.return_value = [
        marathon.MarathonClient('http://marathon.paasta-pnw-devc.yelp'),
        marathon.MarathonClient('http://marathon1.paasta-pnw-devc.yelp'),
        marathon.MarathonClient('http://marathon2.paasta-pnw-devc.yelp'),
    ]
    marathon_gpu_signal = MarathonGPUSignal(mock.Mock(), {'cluster': 'pnw-devc', 'pool': 'gpu'})

    fake_response = """{
        "apps": [
            {
                "id": "/jupyterhub/jupyter.alice",
                "instances": 1,
                "cpus": 2,
                "gpus": 1,
                "mem": 4000,
                "disk": 1024,
                "constraints":[["pool","LIKE","gpu"],["hostname","UNIQUE"]]
            },
            {
                "id": "/jupyterhub/jupyter.alice",
                "instances": 1,
                "cpus": 2,
                "gpus": 1,
                "mem": 4000,
                "disk": 1024,
                "constraints":[["pool","LIKE","default"]]
            }
        ]
    }"""

    fake_response1 = """{
        "apps": [
            {
                "id": "/jupyterhub/jupyter.ignored",
                "instances": 1,
                "cpus": 2,
                "gpus": 0,
                "mem": 4000,
                "disk": 1024
            }
        ]
    }"""

    fake_response2 = """{
        "apps": [
            {
                "id": "/jupyterhub/jupyter.bob",
                "instances": 2,
                "cpus": 2,
                "gpus": 2,
                "mem": 4000,
                "disk": 1024,
                "constraints":[["pool","LIKE","gpu"],["hostname","UNIQUE"]]
            },
            {
                "id": "/jupyterhub/jupyter.bob2",
                "instances": 1,
                "cpus": 2,
                "gpus": 2,
                "mem": 4000,
                "disk": 1024,
                "constraints":[["pool","LIKE","default"]]
            }
        ]
    }"""

    with requests_mock.mock() as m:
        m.get('http://marathon.paasta-pnw-devc.yelp/v2/apps', text=fake_response)
        m.get('http://marathon1.paasta-pnw-devc.yelp/v2/apps', text=fake_response1)
        m.get('http://marathon2.paasta-pnw-devc.yelp/v2/apps', text=fake_response2)
        assert marathon_gpu_signal.value(mock.Mock(), 1234) == SignalResources(gpus=5)
