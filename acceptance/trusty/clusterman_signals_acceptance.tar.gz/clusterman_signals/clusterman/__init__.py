from clusterman_signals.clusterman.most_recent_resources import MostRecentResources

__all__ = [
    'MostRecentResources',
]
