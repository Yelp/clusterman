from abc import ABCMeta
from abc import abstractmethod
from collections import namedtuple


class SignalResources(namedtuple('SignalResources', ['cpus', 'mem', 'disk'])):
    __slots__ = ()

    def __new__(cls, *, cpus=None, mem=None, disk=None):
        return super().__new__(cls, cpus, mem, disk)


class BaseSignal(metaclass=ABCMeta):
    """ The BaseSignal is an abstract class for other signals to inherit from.

    It handles initialization and the fetching of metrics.
    """

    def __init__(self, logger, parameters):
        """ Initialize the BaseSignal.

        Child classes should not change the signature of this method.

        :param logger: a logger that the signal can use to ensure output is received by the service
        :param parameters: dict, custom values used by the signal
        :returns BaseSignal
        """
        self.name = self.__class__.__name__
        self.logger = logger
        self.parameters = parameters

    @abstractmethod
    def value(self, metrics, timestamp):  # pragma: no cover
        """Calculate the estimated amount of resources needed for this app in this cluster.

        :param metrics: a dictionary of key -> timeseries metric data
        :param timestamp: a Unix timestamp indicating when the signal is being evaluated
        :returns: a :class:`.SignalResource` for the required resources
        """
        pass
