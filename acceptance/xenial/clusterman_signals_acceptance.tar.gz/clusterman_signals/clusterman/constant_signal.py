from clusterman_signals.base_signal import BaseSignal
from clusterman_signals.base_signal import SignalResources


class ConstantSignal(BaseSignal):
    """This signal allows the autoscaler to clean up extra fulfilled capacity
    without changing the target capacity.
    """

    def value(self, metrics, timestamp):
        return SignalResources(cpus=None)
