from clusterman_signals.base_signal import BaseSignal
from clusterman_signals.base_signal import SignalResources


class MostRecentResources(BaseSignal):
    def value(self, metrics, timestamp):
        most_recent_cpus = max(metrics['cpus_allocated'], default=(None, None))
        most_recent_mem = max(metrics['mem_allocated'], default=(None, None))
        most_recent_disk = max(metrics['disk_allocated'], default=(None, None))
        return SignalResources(
            cpus=most_recent_cpus[1],
            mem=most_recent_mem[1],
            disk=most_recent_disk[1],
        )
