#!/bin/bash

TAG=`git describe --exact-match --tags HEAD`
no_tag_present=$?
if [ $no_tag_present -ne 0 ]
then
    echo "This branch does not have an associated tag; no artifact will be built."
    echo "If you meant to build the artifact, please add a tag and try again."
    exit 0
fi

ARTIFACT_NAME="clusterman_signals_${TAG}.tar.gz"
tar -czf ${ARTIFACT_NAME} *
aws s3 cp ${ARTIFACT_NAME} "s3://yelp-clusterman-signals/${PLATFORM}/${ARTIFACT_NAME}"
